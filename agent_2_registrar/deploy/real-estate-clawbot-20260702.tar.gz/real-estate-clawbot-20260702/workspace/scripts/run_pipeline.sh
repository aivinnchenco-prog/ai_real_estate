#!/usr/bin/env bash
# Full pipeline: Gate → Agent 2 → Agent 3 → [optional] Agent 4
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROJECT_ROOT="$(cd "$ROOT/../.." && pwd)"
cd "$ROOT"

SESSION=""
SOURCE="Telegram"
SKIP_WAIT=false
PUBLISH=""
PUBLISH_PLATFORMS=""
DRY_RUN=false
FROM_STEP="gate"

usage() {
  cat <<EOF
Usage: $0 --session SESSION_ID [options]

Options:
  --session ID          Session folder under data/sessions/
  --source TEXT         Listing source (Telegram @channel or URL)
  --skip-wait           Skip 150s batch gate wait
  --from-step STEP      gate|agent2|agent3|agent4 (default: gate)
  --publish PLATFORMS   Comma-separated: instagram,tiktok,youtube (runs Agent 4)
  --dry-run             Pass --dry-run to agent2 / publish only

Examples:
  $0 --session test_legendary_20260702 --source "Airbnb https://..."
  $0 --session test_legendary_20260702 --skip-wait --from-step agent3
  $0 --session test_legendary_20260702 --publish instagram,tiktok
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --session) SESSION="$2"; shift 2 ;;
    --source) SOURCE="$2"; shift 2 ;;
    --skip-wait) SKIP_WAIT=true; shift ;;
    --from-step) FROM_STEP="$2"; shift 2 ;;
    --publish) PUBLISH="1"; PUBLISH_PLATFORMS="$2"; shift 2 ;;
    --dry-run) DRY_RUN=true; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown: $1"; usage; exit 1 ;;
  esac
done

if [[ -z "$SESSION" ]]; then
  usage
  exit 1
fi

step_ge() {
  local target="$1"
  local order=(gate agent2 agent3 agent4)
  local from_idx=0 target_idx=0
  for i in "${!order[@]}"; do
    [[ "${order[$i]}" == "$FROM_STEP" ]] && from_idx=$i
    [[ "${order[$i]}" == "$target" ]] && target_idx=$i
  done
  [[ $target_idx -ge $from_idx ]]
}

OBJECT_ID=""
NOTION_PAGE_ID=""

parse_agent2_out() {
  local out="$1"
  OBJECT_ID=$(echo "$out" | python3 -c "
import sys, json
for line in sys.stdin.read().splitlines():
    line = line.strip()
    if line.startswith('{'):
        try:
            d = json.loads(line)
            print(d.get('object_id',''))
            break
        except Exception:
            pass
")
  NOTION_PAGE_ID=$(echo "$out" | python3 -c "
import sys, json
for line in sys.stdin.read().splitlines():
    line = line.strip()
    if line.startswith('{'):
        try:
            d = json.loads(line)
            print(d.get('notion_page_id',''))
            break
        except Exception:
            pass
")
}

load_session_json() {
  local sj="$ROOT/data/sessions/$SESSION/session.json"
  if [[ -f "$sj" ]]; then
    OBJECT_ID=$(python3 -c "import json; print(json.load(open('$sj')).get('object_id',''))")
    NOTION_PAGE_ID=$(python3 -c "import json; print(json.load(open('$sj')).get('notion_page_id',''))")
  fi
}

if step_ge gate; then
  echo "==> [Gate] Waiting for photo batches (150s idle)..."
  if [[ "$SKIP_WAIT" != true ]]; then
    until python3 scripts/media_batch_gate.py ready --session "$SESSION"; do
      sleep 30
    done
  fi
fi

if step_ge agent2; then
  echo "==> [Agent 2] Structurize..."
  AG2_ARGS=(--session "$SESSION" --source "$SOURCE")
  [[ "$DRY_RUN" == true ]] && AG2_ARGS+=(--dry-run)
  OUT=$(python3 scripts/agent2_structurize.py "${AG2_ARGS[@]}")
  echo "$OUT"
  if ! echo "$OUT" | grep -q "READY_FOR_VIDEO"; then
    if [[ "$DRY_RUN" != true ]]; then
      echo "ERROR: Agent 2 did not complete"
      exit 1
    fi
  fi
  parse_agent2_out "$OUT"
fi

load_session_json

if [[ -z "$OBJECT_ID" ]]; then
  echo "ERROR: could not resolve object_id (run agent2 first)"
  exit 1
fi

if step_ge agent3 && [[ "$DRY_RUN" != true ]]; then
  echo "==> [Agent 3] Video render for $OBJECT_ID..."
  node scripts/agent3_video.mjs --object-id "$OBJECT_ID"
fi

load_session_json

if [[ -n "$PUBLISH" ]] && step_ge agent4 && [[ "$DRY_RUN" != true ]]; then
  if [[ -z "$NOTION_PAGE_ID" ]]; then
    echo "ERROR: notion_page_id missing — run agent2 first"
    exit 1
  fi
  PUBLISH_SCRIPT="$PROJECT_ROOT/workspaces/publisher/scripts/publish_pipeline.py"
  if [[ ! -f "$PUBLISH_SCRIPT" ]]; then
    echo "WARN: Agent 4 not found at $PUBLISH_SCRIPT"
    exit 0
  fi
  IFS=',' read -ra PLATFORMS <<< "$PUBLISH_PLATFORMS"
  for platform in "${PLATFORMS[@]}"; do
    platform=$(echo "$platform" | tr -d ' ')
    [[ -z "$platform" ]] && continue
    echo "==> [Agent 4] Publish $platform for page $NOTION_PAGE_ID..."
    python3 "$PUBLISH_SCRIPT" --page-id "$NOTION_PAGE_ID" --platform "$platform" || true
  done
fi

echo ""
echo "==> Pipeline done"
echo "    object_id:      $OBJECT_ID"
echo "    notion_page_id: ${NOTION_PAGE_ID:-n/a}"
if [[ -z "$PUBLISH" && "$DRY_RUN" != true ]]; then
  echo "    Next: $0 --session $SESSION --from-step agent4 --publish instagram"
fi
