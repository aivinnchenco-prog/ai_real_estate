# TOOLS.md — Real Estate Pipeline

## Env
Load from `.env.real-estate` or `.env` in workspace root.

## Agent 2 — Batch wait
```bash
python3 scripts/media_batch_gate.py init --session SESSION_ID --description "..."
python3 scripts/media_batch_gate.py bump --session SESSION_ID --count 10
python3 scripts/media_batch_gate.py ready --session SESSION_ID
python3 scripts/agent2_structurize.py --session SESSION_ID --source "Telegram @x"
```

## Agent 3 — Video
```bash
# Curator must run on :8077
uvicorn curator_service:app --host 127.0.0.1 --port 8077

node scripts/agent3_video.mjs --object-id OBJ_20260630_abc123
```

## Agent 4 — Publisher (Publora)
```bash
python3 workspaces/publisher/scripts/publish_pipeline.py --page-id PAGE_ID --platform instagram
```

## Full pipeline
```bash
./scripts/run_pipeline.sh --session SESSION_ID --source "Telegram"
```

## Notion CRM
- Database: `e817ce50-e788-4992-8b86-c9c9fc1fbcf7`
- Contact: +66625124001

## R2
- Bucket: `real-estate-propertiess`
- Music: `music/track_001.mp3` … `track_003.mp3`
- Photos: `{object_id}/photos/`
- Videos: `{object_id}/video_1x1.mp4`, `video_3x4.mp4`, `video_9x16.mp4`

## Config
`config/pipeline.json` — wait seconds, field names, statuses
