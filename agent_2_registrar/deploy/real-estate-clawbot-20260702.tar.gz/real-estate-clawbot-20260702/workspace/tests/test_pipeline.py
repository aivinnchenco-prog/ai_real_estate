#!/usr/bin/env python3
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from housing_type import detect_housing_type  # noqa: E402
from listing_parser import parse_listing  # noqa: E402
from session_store import bind_object_id, get_object_id, load_session  # noqa: E402


LEGENDARY = """
TITLE LEGENDARY 2BR с видом на бассейн / БАНГТАО
The Title Legendary Bang-Tao — современный курортный комплекс
Возвратный депозит 200 USD
Wi-Fi, бассейн, фитнес, детские игровые комнаты
"""


class HousingTypeTests(unittest.TestCase):
    def test_legendary_is_condo(self):
        ht = detect_housing_type(LEGENDARY, title="TITLE LEGENDARY 2BR")
        self.assertEqual(ht, "Кондоминиум")

    def test_villa(self):
        ht = detect_housing_type("Private pool villa 4BR in Rawai", title="Villa")
        self.assertEqual(ht, "Вилла")


class ListingParserTests(unittest.TestCase):
    def test_deposit_and_amenities(self):
        d = parse_listing(LEGENDARY, districts=["Choeng Thale"], source="Airbnb https://x.com")
        self.assertEqual(d.rooms, 2)
        self.assertEqual(d.deposit, 200.0)
        self.assertEqual(d.rent_type, "Краткосрочная")
        self.assertIn("Бассейн", d.amenities)
        self.assertEqual(d.view, "Бассейн")


class SessionStoreTests(unittest.TestCase):
    def test_one_id_per_session(self):
        sid = "_test_session_bind"
        bind_object_id(sid, "20260701_099")
        self.assertEqual(get_object_id(sid), "20260701_099")
        bind_object_id(sid, "20260701_099")
        self.assertEqual(load_session(sid)["object_id"], "20260701_099")
        (ROOT / "data" / "sessions" / sid / "session.json").unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main()
