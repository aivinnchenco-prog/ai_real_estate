# AGENTS.md — Agent 2: Strukturator (Real Estate)

Ты **Агент 2 — Strukturator**. Структурируешь объекты в Notion CRM и загружаешь фото в R2.

**Агент 3 подключай ТОЛЬКО после полного завершения Агента 2.**  
**Агент 4 — только после `ready_to_post`.**

## Правило ожидания фото (КРИТИЧНО)

Telegram присылает фото **пачками (~10 шт.)**. Не один раз 150 сек, а **после каждой новой пачки**:

```
Описание получено → init session
    ↓
Пачка фото (N шт.) → сохранить в data/sessions/{id}/photos/ → bump
    ↓
ЖДАТЬ 150 секунд
    ↓
Новая пачка? → bump → снова ЖДАТЬ 150 сек
    ↓
150 сек прошло, новых фото НЕТ → ready → Agent 2
```

### Команды

```bash
# 1. Новый объект — сразу после описания
python3 scripts/media_batch_gate.py init --session "$SESSION_ID" --description "..."

# 2. После КАЖДОЙ пачки фото (сохрани файлы в data/sessions/$SESSION_ID/photos/)
python3 scripts/media_batch_gate.py bump --session "$SESSION_ID" --count 10

# 3. Проверка готовности (повторяй, не чаще раз в 30 сек)
python3 scripts/media_batch_gate.py ready --session "$SESSION_ID"
# Вывод "ready" → можно структурировать
```

## One session = one object_id

Файл `data/sessions/{session}/session.json` хранит привязку session → object_id.
Повторный запуск Agent 2 для той же session **обновляет** тот же объект (Notion + R2), новый ID не создаётся.

## Полный пайплайн

```bash
./scripts/run_pipeline.sh --session "$SESSION_ID" --source "Airbnb https://..."
./scripts/run_pipeline.sh --session "$SESSION_ID" --skip-wait --from-step agent3
./scripts/run_pipeline.sh --session "$SESSION_ID" --publish instagram,tiktok
```

## Agent 2 — структуризация (когда gate = ready)

```bash
python3 scripts/agent2_structurize.py --session "$SESSION_ID" --source "Telegram @channel"
```

Скрипт:
1. Берёт или создаёт **Объект ID** (`YYYYMMDD_NNN`) — **один ID на session** (`session.json`)
2. Извлекает район, тип жилья, вид, залог, удобства, тип аренды (`listing_parser.py`)
3. **Google Maps** — карточка проекта через Places API (`maps_resolver.py`)
4. Загружает фото в R2 + **index.html** галерея
5. Заполняет Notion (включая Тип жилья, Вид, Удобства, Залог)
6. Статус → `ready_for_video` → `READY_FOR_VIDEO`

### Обязательные поля (не пропускать!)

- Название объекта, Объект ID, Адрес, **Район**
- **Google Maps**, **Источник объявления**
- Фото (URL), Описание, Описание для Telegram, Описание для FB Marketplace
- Статус

## Agent 3 — только после READY_FOR_VIDEO

```bash
node scripts/agent3_video.mjs --object-id "$OBJECT_ID"
```

- Берёт фото из R2 `{object_id}/photos/`
- Curator (:8077) → лучшие 6 кадров; fallback если curator offline
- При ошибке → `video_failed` + `last_error` + `error_count`
- Музыка из R2 `/music/track_00X.mp3` (ротация)
- Рендер: min 15 сек, 2.5 сек/кадр, zoom in/out рандом
- Форматы: 1x1, 3x4, 9x16 → `video_url_square/vertical/wide`
- Статус → `ready_to_post`
- Печатает `READY_TO_POST`

## Agent 4 — только после READY_TO_POST

```bash
python3 workspaces/publisher/scripts/publish_pipeline.py --page-id "$PAGE_ID" --platform instagram
```

## Запрещено

- ❌ Запускать Agent 3 до загрузки всех фото и заполнения Notion
- ❌ Один раз подождать 150 сек и сразу работать (нужно ждать после КАЖДОЙ пачки)
- ❌ Пропускать Google Maps и Источник объявления
- ❌ Публиковать (Agent 4) до `ready_to_post`

## При ошибке

- Запиши в `last_error` в Notion
- Не меняй статус вперёд без успеха
- Сообщи пользователю что сломалось

## Документация

- `docs/CRM_SCHEMA.md` или `CRM_SCHEMA.md`
- `config/pipeline.json`
- `AGENT2_CHECKLIST.md`
